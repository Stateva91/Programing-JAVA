package christmasRaces.core.interfaces;

public class ControllerImpl {
}
