package christmasPastryShop.core;

import christmasPastryShop.common.ExceptionMessages;
import christmasPastryShop.common.OutputMessages;
import christmasPastryShop.core.interfaces.Controller;
import christmasPastryShop.entities.booths.interfaces.OpenBooth;
import christmasPastryShop.entities.booths.interfaces.PrivateBooth;
import christmasPastryShop.entities.cocktails.interfaces.Hibernation;
import christmasPastryShop.entities.cocktails.interfaces.MulledWine;
import christmasPastryShop.entities.delicacies.interfaces.Delicacy;
import christmasPastryShop.entities.cocktails.interfaces.Cocktail;
import christmasPastryShop.entities.booths.interfaces.Booth;
import christmasPastryShop.entities.delicacies.interfaces.Gingerbread;
import christmasPastryShop.entities.delicacies.interfaces.Stolen;
import christmasPastryShop.repositories.interfaces.BoothRepository;
import christmasPastryShop.repositories.interfaces.CocktailRepository;
import christmasPastryShop.repositories.interfaces.DelicacyRepository;

import java.util.LinkedHashMap;
import java.util.Map;

public class ControllerImpl implements Controller {
    private Map<String, Delicacy> delicacys;
    private Map<String, Cocktail> cocktails;
    private Map<String, Booth> booths;

    public ControllerImpl() {
        this.delicacys = new LinkedHashMap<>();
        this.cocktails = new LinkedHashMap<>();
        this.booths = new LinkedHashMap<>();
    }


//    public ControllerImpl(DelicacyRepository<Delicacy> delicacyRepository, CocktailRepository<Cocktail> cocktailRepository, BoothRepository<Booth> boothRepository) {
//    }


    @Override
    public String addDelicacy(String type, String name, double price) {
        Delicacy delicacy;
        switch (type){
            case "Stolen":
                delicacy=new Stolen(name, price);
                break;
            case "Gingerbread":
                delicacy=new Gingerbread(name, price);
                break;
            default:
                throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }
        delicacys.put(name,delicacy);
        return String.format(OutputMessages.DELICACY_ADDED,name, type);
    }

    @Override
    public String addCocktail(String type, String name, int portion, String brand) {
        Cocktail cocktail;
        switch (type){
            case "Hibernation":
                cocktail=new Hibernation(name,portion, brand);
                break;
            case "MulledWine":
                cocktail=new MulledWine(name, portion, brand);
                break;
            default:
                throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_OR_DRINK_EXIST, type, name));
        }
        cocktails.put(name,cocktail);
        return String.format(OutputMessages.COCKTAIL_ADDED,name, brand);
    }

    @Override
    public String addBooth(String type, int boothNumber, int capacity) {
        Booth booth;
        switch (type){
            case "OpenBooth":
                booth=new OpenBooth(boothNumber, capacity);
                break;
            case "PrivateBooth":
                booth=new PrivateBooth(boothNumber, capacity);
                break;
            default:
                throw new IllegalArgumentException(String.format(ExceptionMessages.BOOTH_EXIST, boothNumber));
        }
        booths.put(type,booth);
        return String.format(OutputMessages.BOOTH_ADDED,boothNumber);
    }

    @Override
    public String reserveBooth(int numberOfPeople) {
        //TODO
        return null;
    }

    @Override
    public String leaveBooth(int boothNumber) {
        //TODO
        return null;
    }

    @Override
    public String getIncome() {
        //TODO
        return null;
    }
}
