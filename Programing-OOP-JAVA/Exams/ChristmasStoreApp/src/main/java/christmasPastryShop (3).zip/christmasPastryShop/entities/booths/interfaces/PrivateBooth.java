package christmasPastryShop.entities.booths.interfaces;

public class PrivateBooth extends BaseBooth{
    public PrivateBooth(int boothNumber, int capacity) {
        super(boothNumber, capacity, 3.50);
    }
}
