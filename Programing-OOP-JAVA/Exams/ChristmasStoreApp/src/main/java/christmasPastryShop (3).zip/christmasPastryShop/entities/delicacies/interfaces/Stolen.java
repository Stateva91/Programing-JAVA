package christmasPastryShop.entities.delicacies.interfaces;

public class Stolen extends BaseDelicacy{
    public Stolen(String name, double price) {
        super(name, 250, price);
    }
}
