package christmasPastryShop.entities.booths.interfaces;

public class OpenBooth extends BaseBooth{
    public OpenBooth(int boothNumber, int capacity) {
        super(boothNumber, capacity, 2.50);
    }
}
