package christmasPastryShop.entities.cocktails.interfaces;

public class Hibernation extends BaseCocktail{
    public Hibernation(String name, int size, String brand) {
        super(name, size, 4.5, brand);
    }
}
