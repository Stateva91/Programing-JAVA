package christmasPastryShop.repositories.interfaces;

import java.util.Collection;

public class BoothRepositoryImpl implements BoothRepository{
    @Override
    public Object getByNumber(int number) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
