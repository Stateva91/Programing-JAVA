package christmasPastryShop.repositories.interfaces;

import java.util.Collection;

public class CocktailRepositoryImpl implements CocktailRepository{
    @Override
    public Object getByName(String name) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
