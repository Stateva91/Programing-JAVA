package glacialExpedition.core;

import glacialExpedition.common.ConstantMessages;
import glacialExpedition.common.ExceptionMessages;
import glacialExpedition.models.explorers.AnimalExplorer;
import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.explorers.GlacierExplorer;
import glacialExpedition.models.explorers.NaturalExplorer;
import glacialExpedition.models.states.State;
import glacialExpedition.models.states.StateImpl;
import glacialExpedition.repositories.ExplorerRepository;
import glacialExpedition.repositories.StateRepository;

import java.util.Arrays;
import java.util.List;


public class ControllerImpl implements Controller {

    private ExplorerRepository<Explorer> explorerRepository;
    private StateRepository<State> stateStateRepository;

    private int count;
    public ControllerImpl() {
        this.explorerRepository = new ExplorerRepository();
        this.stateStateRepository=new StateRepository();
        this.count=0;
    }

    @Override
    public String addExplorer(String type, String explorerName) {

        Explorer explorer;
        switch (type) {
            case "AnimalExplorer":
                explorer = new AnimalExplorer(explorerName);
                break;
            case "GlacierExplorer":
               explorer = new GlacierExplorer(explorerName);
                break;
            case "NaturalExplorer":
                explorer = new NaturalExplorer(explorerName);
                break;
            default:
                throw new IllegalArgumentException(ExceptionMessages.EXPLORER_INVALID_TYPE);
        }
        this.explorerRepository.add(explorer);

        return String.format(ConstantMessages.EXPLORER_ADDED, type, explorerName);
    }

    @Override
    public String addState(String stateName, String... exhibits) {

        State state=new StateImpl(stateName);

        List<String> items = Arrays.asList(exhibits);
        state.getExhibits().addAll(items);
        this.stateStateRepository.add(state);

        return String.format(ConstantMessages.STATE_ADDED, stateName);
    }

    @Override
    public String retireExplorer(String explorerName) {

      Explorer explorer = this.explorerRepository.byName(explorerName);
        if(explorer==null){
            String msg =String.format(ExceptionMessages.EXPLORER_DOES_NOT_EXIST, explorerName);
            throw new IllegalArgumentException(msg);
        }
        this.explorerRepository.remove(explorer);
        return String.format(ConstantMessages.EXPLORER_RETIRED, explorerName);
    }

    @Override
    public String exploreState(String stateName) {
        return null;
    }

    @Override
    public String finalResult() {

        return null;
    }
}
