package glacialExpedition.repositories;

import glacialExpedition.models.states.State;

import java.util.ArrayList;
import java.util.Collection;

public class StateRepository<T> implements Repository<State>{

    private Collection<State>states;

    public StateRepository(Collection<State> states) {
        this.states = new ArrayList<>();
    }

    @Override
    public Collection<State> getCollection() {
        return this.states;
    }

    @Override
    public void add(State entity) {
    states.add(entity);
    }

    @Override
    public boolean remove(State entity) {
        return states.remove(entity);
    }

    @Override
    public State byName(String name) {
         return this.states.stream()
                .filter(t -> t.getClass().getSimpleName().equals(name))
                .findFirst()
                .orElse(null);
    }
}
