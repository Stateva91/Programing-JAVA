package goldDigger.core;

import goldDigger.common.ConstantMessages;
import goldDigger.common.ExceptionMessages;
import goldDigger.models.discoverer.Anthropologist;
import goldDigger.models.discoverer.Archaeologist;
import goldDigger.models.discoverer.Discoverer;
import goldDigger.models.discoverer.Geologist;
import goldDigger.models.spot.Spot;
import goldDigger.models.spot.SpotImpl;
import goldDigger.repositories.DiscovererRepository;
import goldDigger.repositories.SpotRepository;

import java.util.Arrays;
import java.util.List;

public class ControllerImpl implements Controller{
    private DiscovererRepository discovererRepository;
    private SpotRepository spotRepository;

    public ControllerImpl() {
        this.discovererRepository=new DiscovererRepository();
        this.spotRepository=new SpotRepository();

    }
    @Override
    public String addDiscoverer(String kind, String discovererName) {

        //Check kind
        //Throw  if invalid kind
        //Create discoverer
        //Store in repo
        //Result
        Discoverer discoverer=null; //null
        if(kind.equals("Anthropologist")){
            discoverer=new Anthropologist(discovererName);
        }else if(kind.equals("Archaeologist")){
            discoverer=new Archaeologist(discovererName);
        }else if(kind.equals("Geologist")){
            discoverer=new Geologist(discovererName);
        }else {
            throw new IllegalArgumentException(ExceptionMessages.DISCOVERER_INVALID_KIND);
        }
        discovererRepository.add(discoverer);
        return String.format(ConstantMessages.DISCOVERER_ADDED,kind, discovererName);
    }

    @Override
    public String addSpot(String spotName, String... exhibits) {
        Spot spot=new SpotImpl(spotName);

        List<String> items = Arrays.asList(exhibits);
        spot.getExhibits().addAll(items);
        this.spotRepository.add(spot);

        return String.format(ConstantMessages.SPOT_ADDED, spotName);
    }

    @Override
    public String excludeDiscoverer(String discovererName) {
        Discoverer discoverer = this.discovererRepository.byName(discovererName);
        if(discoverer==null){
            String msg =String.format(ExceptionMessages.DISCOVERER_DOES_NOT_EXIST, discovererName);
            throw new IllegalArgumentException(msg);
        }
        this.discovererRepository.remove(discoverer);
        return String.format(ConstantMessages.DISCOVERER_EXCLUDE, discovererName);

    }

    @Override
    public String inspectSpot(String spotName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
