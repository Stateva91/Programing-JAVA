package magicGame.models.magics;

public class BlackMagic extends MagicImpl{


    public BlackMagic(int bulletsCount, String name) {
        super(bulletsCount, name);
    }
    @Override
    public int fire() {
        return doFire(10);
    }
}
