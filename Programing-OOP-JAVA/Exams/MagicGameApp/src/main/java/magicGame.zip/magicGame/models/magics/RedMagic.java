package magicGame.models.magics;

public class RedMagic extends MagicImpl{
    public RedMagic(int bulletsCount, String name) {
        super(bulletsCount, name);
    }

    @Override
    public int fire() {
     return doFire(1);
    }
}
