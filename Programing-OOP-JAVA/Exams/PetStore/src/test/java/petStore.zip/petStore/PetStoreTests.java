package petStore;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class PetStoreTests {
    private PetStore petStore;
    private Animal animal;

    @Before
    public void setUp() {
        petStore = new PetStore();
        animal = new Animal("Cat", 19, 599.45);

        petStore.addAnimal(animal);
    }

    @Test(expected = IllegalArgumentException.class)  // Tested N1
    public void addCarShouldThrow() {
        Animal petNull = null;

        petStore.addAnimal(petNull);
    }

    @Test
    public void getCOuntShouldReturnOne() { // Tested N3
        int actualCount = petStore.getCount();
        int expectedCount = 1;
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void getCarsShouldReturnCorrectList() { //Not
        List<Animal> expected = new ArrayList<>();
        expected.add(animal);

        List<Animal> actualCars = petStore.getAnimals();

        assertEquals(expected, actualCars);
    }

    @Test
    public void findCarsMaxSPetsStoreReturnCorrectList() { //Tested N2
        Animal pet2 = new Animal("Pet2", 10, 24);
        Animal pet3 = new Animal("Pet3", 199, 24);
        Animal pet4 = new Animal("Pet4", 192, 22);
        petStore.addAnimal(pet2);
        petStore.addAnimal(pet3);
        petStore.addAnimal(pet4);

        List<Animal> expectedCars = new ArrayList<>(Arrays.asList(animal,pet3, pet4));
        List<Animal> actualCars = petStore.findAllAnimalsWithMaxKilograms(190);

        assertEquals(expectedCars,actualCars);
    }


    @Test
    public void getMOstExpensiveCarShudlReturnCorrectPet(){ //Tested N4
        Animal pet2 = new Animal("Pet2", 10, 24);
        Animal pet3 = new Animal("Pet3", 199, 24);
        Animal pet4 = new Animal("Pet4", 192, 22);
        petStore.addAnimal(pet2);
        petStore.addAnimal(pet3);
        petStore.addAnimal(pet4);


        Animal actualResult = petStore.getTheMostExpensiveAnimal();
        assertEquals(animal,actualResult);
    }

    @Test
    public void findAllCarsByBrandShouldReturnCorrectList(){
        Animal pet2 = new Animal("Pet2", 10, 24);
        Animal pet3 = new Animal("Pet3", 199, 24);
        Animal pet4 = new Animal("Pet4", 192, 22);
        petStore.addAnimal(pet2);
        petStore.addAnimal(pet3);
        petStore.addAnimal(pet4);


        List<Animal> expectedCars = new ArrayList<>(Arrays.asList(animal,pet2));
        List<Animal> actualCars = petStore.findAllAnimalBySpecie("Pet");

        assertEquals(expectedCars,actualCars);
    }

}

