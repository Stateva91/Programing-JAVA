package robotService.entities.services;

public class SecondaryService extends BaseService{
    public SecondaryService(String name) {
        super(name, 15);
    }

    @Override
    public void setName(String name) {

    }
}
