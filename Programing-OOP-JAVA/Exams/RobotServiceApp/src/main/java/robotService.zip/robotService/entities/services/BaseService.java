package robotService.entities.services;

import robotService.common.ExceptionMessages;
import robotService.entities.robot.Robot;
import robotService.entities.supplements.Supplement;

import java.util.Collection;

public abstract class BaseService implements Service{

    private String name;
    private int capacity;
    private Collection<Supplement> supplements;
    private Collection<Robot> robots;

    public BaseService(String name, int capacity) {
        if(name==null || name.trim().isEmpty()){
            throw new NullPointerException(ExceptionMessages.SERVICE_NAME_CANNOT_BE_NULL_OR_EMPTY);
        }
        this.name = name;
        this.capacity = capacity;

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public Collection<Robot> getRobots() {
        return null;
    }

    @Override
    public Collection<Supplement> getSupplements() {
        return null;
    }

    @Override
    public void addRobot(Robot robot) {

    }

    @Override
    public void removeRobot(Robot robot) {

    }

    @Override
    public void addSupplement(Supplement supplement) {

    }

    @Override
    public void feeding() {

    }

    @Override
    public int sumHardness() {
        return 0;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
