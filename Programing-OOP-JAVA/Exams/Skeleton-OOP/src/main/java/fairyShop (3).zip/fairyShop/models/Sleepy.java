package fairyShop.models;

public class Sleepy extends BaseHelper{
    public Sleepy(String name) {
        super(name, 50);
    }
}
