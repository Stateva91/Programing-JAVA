package fairyShop.models;

public  class ShopImpl implements Shop{
    @Override
    public void craft(Present present, Helper helper) {

    }
}
