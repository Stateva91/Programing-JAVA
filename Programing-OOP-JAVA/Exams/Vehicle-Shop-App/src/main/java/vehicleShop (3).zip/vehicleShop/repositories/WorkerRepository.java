package vehicleShop.repositories;

import vehicleShop.models.worker.Worker;

import java.util.Collection;

public class WorkerRepository implements Repository<Worker>{

   private Collection<Worker>workers;


    @Override
    public Collection<Worker> getWorkers() {
        return null;
    }

    @Override
    public void add(Worker model) {

    }

    @Override
    public boolean remove(Worker model) {
        return false;
    }

    @Override
    public Worker findByName(String name) {
        return null;
    }
}
